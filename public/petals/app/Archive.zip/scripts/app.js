'use strict';

/**
 * @ngdoc overview
 * @name petalsApp
 * @description
 * # petalsApp
 *
 * Main module of the application.
 */
angular
  .module('petalsApp', [
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch',
    'angularFileUpload'
  ])
  .config(function ($routeProvider) {
    $routeProvider
      .when('/purposes/new', {
        //templateUrl: 'views/main.html',
        //controller: 'MainCtrl'
        title: 'New Article',
        templateUrl: 'views/purposes/new.html',
        controller: 'NewPurposeCtrl'
      })
      .when('/purposes/edit/:purposeid', {
        //templateUrl: 'views/main.html',
        //controller: 'MainCtrl'
        title: 'Edit Article',
        templateUrl: 'views/purposes/edit.html',
        controller: 'EditPurposeCtrl'
      })
      .when('/purposes', {
        //templateUrl: 'views/main.html',
        //controller: 'MainCtrl'
        title: 'Purposes',
        templateUrl: 'views/purposes/main.html',
        controller: 'PurposesCtrl'
      })
      .when('/feminique-woman', {
        //templateUrl: 'views/main.html',
        //controller: 'MainCtrl'
        title: 'Femique Woman',
        templateUrl: 'views/feminique/main.html',
        controller: 'FeminiqueCtrl'
      })
      .when('/feminique-woman/edit/:purposeid', {
        //templateUrl: 'views/main.html',
        //controller: 'MainCtrl'
        title: 'Edit Article',
        templateUrl: 'views/feminique/edit.html',
        controller: 'EditFeminiqueCtrl'
      })
      .when('/feminique-woman/new', {
        templateUrl: 'views/feminique/new.html',
        controller: 'NewFeminiqueCtrl'
      })
      .when('/unique-man', {
        //templateUrl: 'views/main.html',
        //controller: 'MainCtrl'
        title: 'Unique Man',
        templateUrl: 'views/unique/main.html',
        controller: 'UniqueCtrl'
      })
      .when('/unique-man/edit/:purposeid', {
        //templateUrl: 'views/main.html',
        //controller: 'MainCtrl'
        title: 'Edit Article',
        templateUrl: 'views/unique/edit.html',
        controller: 'EditUniqueCtrl'
      })
      .when('/unique-man/new', {
        templateUrl: 'views/unique/new.html',
        controller: 'NewUniqueCtrl'
      })
      .when('/ask-kenny', {
        //templateUrl: 'views/main.html',
        //controller: 'MainCtrl'
        title: 'Ask Kenny',
        templateUrl: 'views/ask-kenny/main.html',
        controller: 'AskKennyCtrl'
      })
      .when('/ask-kenny/edit/:purposeid', {
        //templateUrl: 'views/main.html',
        //controller: 'MainCtrl'
        title: 'Edit Question',
        templateUrl: 'views/ask-kenny/edit.html',
        controller: 'EditAskKennyCtrl'
      })
      .when('/events', {
        //templateUrl: 'views/main.html',
        //controller: 'MainCtrl'
        title: 'Events',
        templateUrl: 'views/events/main.html',
        controller: 'EventsCtrl'
      })
      .when('/events/edit/:purposeid', {
        //templateUrl: 'views/main.html',
        //controller: 'MainCtrl'
        title: 'Events',
        templateUrl: 'views/events/edit.html',
        controller: 'EditEventsCtrl'
      })
      .when('/events/new', {
        //templateUrl: 'views/main.html',
        //controller: 'MainCtrl'
        title: 'New Event',
        templateUrl: 'views/events/new.html',
        controller: 'NewEventCtrl'
      })
      .when('/blog', {
        templateUrl: 'views/blog/main.html',
        controller: 'BlogCtrl'
      })
      .when('/blog/new', {
        templateUrl: 'views/blog/new.html',
        controller: 'NewBlogCtrl'
      })
      .when('/blog/edit/:purposeid', {
        //templateUrl: 'views/main.html',
        //controller: 'MainCtrl'
        title: 'Edit Blog',
        templateUrl: 'views/blog/edit.html',
        controller: 'EditBlogCtrl'
      })
      .when('/covers', {
        templateUrl: 'views/covers/main.html',
        controller: 'CoversCtrl'
      })
      .when('/about', {
        templateUrl: 'views/about.html',
        controller: 'AboutCtrl'
      })
      .otherwise({
        redirectTo: '/purposes'
      });
  });
